import 'package:flutter/material.dart';

class AnimatedFlag extends StatefulWidget {
  final String imagePath;
  const AnimatedFlag({super.key, required this.imagePath});

  @override
  State<AnimatedFlag> createState() => _AnimatedFlagState();
}

class _AnimatedFlagState extends State<AnimatedFlag>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _animation;

  @override
  void initState() {
    super.initState();
    _controller =
    AnimationController(vsync: this, duration: const Duration(seconds: 3))
      ..repeat(reverse: true);

    _animation = Tween<Offset>(
      begin: const Offset(0, 0),
      end: const Offset(0, 0.05), // float down 2%
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SlideTransition(
      position: _animation,
      child: ScaleTransition(
        scale: Tween<double>(begin: 1.0, end: 1.08) // 8% scale
            .animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut)),
        child: CircleAvatar(
          backgroundImage: AssetImage(widget.imagePath),
        ),
      ),
    );

  }
}


